package com.rjxz.xykd.service.impl;

import com.rjxz.xykd.bean.User;
import com.rjxz.xykd.dao.UserMapper;
import com.rjxz.xykd.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService implements IUserService {

    @Autowired
    private UserMapper userMapper;

    @Override
    public User login(String username, String password) {
        return userMapper.selectByEmailAndPwd(username, password);
    }

    @Override
    public boolean register(User user) {
        int result = userMapper.insert(user);
        return result > 0 ? true : false;
    }

    @Override
    public boolean update(User user) {
        int result = userMapper.updateByPrimaryKey(user);
        return result > 0 ? true : false;
    }

    @Override
    public boolean delete(Long id) {
        int result=userMapper.deleteByPrimaryKey(id);
        return result > 0 ? true : false;
    }

    @Override
    public Object getAllUserInfo() {
        List<User> allUserInfo=userMapper.selectAll();
        return allUserInfo;
    }
}
