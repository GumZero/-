package com.rjxz.xykd.controller;

import com.rjxz.xykd.util.EmailUtil;
import com.github.cage.GCage;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@Controller
public class CommonServiceController {

    //发送验证码并保存在session中
    @GetMapping("/getAuthCode")
    public @ResponseBody Object getAuthCode(HttpServletRequest request, HttpServletResponse response){

        GCage cage = new GCage();
        HttpSession session = request.getSession();
        String authCode = cage.getTokenGenerator().next().substring(0,4);
        session.setAttribute("authCode", authCode);
        try {
            cage.draw(authCode, response.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                response.getOutputStream().flush();
                response.getOutputStream().close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return authCode;
    }

    //获取验证码图片字符串
    @GetMapping("/getAuthCodeStr")
    public @ResponseBody Object getAuthCodeStr(HttpServletRequest request){

        HttpSession session = request.getSession(false);
        return session.getAttribute("authCode");
    }

    @GetMapping("/getEmailCode")
    public @ResponseBody Object getEmailCode(String address, String personal){

        String emailCode = null;
        try {
            emailCode = EmailUtil.sendEmail("2086846171@qq.com", "wqh");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return emailCode;
    }

    //七天免登录
    public @ResponseBody Object setAvoidTheLogin(HttpServletRequest request, HttpServletResponse response){

        return null;
    }


}
