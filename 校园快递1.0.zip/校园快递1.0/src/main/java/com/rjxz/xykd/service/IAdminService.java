package com.rjxz.xykd.service;

import com.rjxz.xykd.bean.Admin;

public interface IAdminService {

    //登录
    Admin login(String username, String password);

    //注册
    boolean register(Admin admin);

    //修改个人中心
    boolean update(Admin admin);

}
