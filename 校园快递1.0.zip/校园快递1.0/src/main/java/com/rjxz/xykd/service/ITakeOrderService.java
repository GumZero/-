package com.rjxz.xykd.service;

import com.rjxz.xykd.bean.Takeorder;

import java.util.List;

public interface ITakeOrderService {

    //提交代取订单
    boolean submitOrderTake(Takeorder ordertake);

    //查看所有代取订单
    Object getAllTakeOrder();

    //查询用户代取订单
    List<Takeorder> getOrderTakeList(long userId);

    //修改代买订单
    boolean updateTakeOrder(Takeorder ordertake);

    //删除代买订单
    boolean deleteTakeOrder(Long id);

    //查看未接订单
    Object getUndoneOrder();

    //查看订单接单人
    String getCourier(Long id);

}
