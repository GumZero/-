package com.rjxz.xykd.controller;

import com.rjxz.xykd.bean.Buyorder;
import com.rjxz.xykd.bean.User;
import com.rjxz.xykd.service.IBuyOrderService;
import com.rjxz.xykd.util.IDGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.sql.Timestamp;

@RestController
public class BuyOrderController {

    @Autowired
    private IBuyOrderService buyOrderService;

    //提交代买订单
    @PostMapping("/user/submitOrderBuy")
    public Object submitOrderBuy(HttpServletRequest request){

        //购买内容
        String buyContent = request.getParameter("buyContent");
        //商品价格
        double commodityPrices = Double.parseDouble(request.getParameter("commodityPrices"));
        //备注
        String notes = request.getParameter("notes");
        //收货地址
        String receiverAddr = request.getParameter("receiverAddr");
        //收货备注地址
        String receiverNoteAddr = request.getParameter("receiverNoteAddr");
        //收货电话
        String phone = request.getParameter("phone");
        //购买地址
        String buyAddr = request.getParameter("buyAddr");
        //购买备注地址
        String buyNoteAddr = request.getParameter("buyNoteAddr");
        //要求
        String demand = request.getParameter("demand");

        //绑定用户
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("account");
        long userId = user.getId();

        //获取当前系统时间
        Timestamp time = new Timestamp(System.currentTimeMillis());

        Buyorder order = new Buyorder();
        long id = IDGenerator.getInstance().getId();
        order.setId(id);
        order.setBuyaddr(buyAddr);
        order.setBuycontent(buyContent);
        order.setBuynoteaddr(buyNoteAddr);
        order.setCommodityprices(commodityPrices);
        order.setDemand(demand);
        order.setNotes(notes);
        order.setPhone(phone);
        order.setReceiveraddr(receiverAddr);
        order.setReceivernoteaddr(receiverNoteAddr);
        order.setUserid(userId);
        order.setCourierid(null);
        order.setTime(time);

        return buyOrderService.submitOrderBuy(order);
    }

    //获取用户个人代买订单
    @GetMapping("/user/getOrderBuyList")
    public Object getOrderBuyList(HttpServletRequest request){

        long userId =  Long.parseLong(request.getParameter("userId"));
        return buyOrderService.getOrderBuyList(userId);
    }

    //获取全部代买订单
    @GetMapping("/admin/getAllBuyOrder")
    public Object getAllBuyOrder()
    {
        return buyOrderService.getAllBuyOrder();
    }

    //修改代买订单
    @PostMapping("/admin/updateBuyOrder")
    public boolean updateBuyOrder(HttpServletRequest request)
    {
        boolean flag=false;

        Buyorder order = new Buyorder();

        order.setId(Long.parseLong(request.getParameter("id")));
        order.setBuycontent(request.getParameter("buyContent"));
        order.setCommodityprices(Double.parseDouble(request.getParameter("commodityPrices")));
        order.setNotes(request.getParameter("notes"));
        order.setReceiveraddr(request.getParameter("receiverAddr"));
        order.setReceivernoteaddr(request.getParameter("receiverNoteAddr"));
        order.setPhone(request.getParameter("phone"));
        //待定
        order.setBuyaddr(request.getParameter("buyAddr"));
        order.setBuynoteaddr(request.getParameter("buyNoteAddr"));

        order.setDemand(request.getParameter("demand"));
        order.setUserid(Long.parseLong(request.getParameter("userId")));

        flag=buyOrderService.updateBuyOrder(order);
        return flag;
    }

    @PostMapping("/admin/deleteBuyOrder")
    public boolean deleteBuyOrder(HttpServletRequest request)
    {
        String orderId=request.getParameter("id");
        return buyOrderService.deleteBuyOrder(Long.parseLong(orderId));
    }

    //获取未接的所有订单
    @GetMapping("/staff/getUndoneBuyOrder")
    public Object getUndoneBuyOrder(){
        return buyOrderService.getUndoneOrder();
    }

    //查看单个订单是否已被接单
    @GetMapping("/staff/getBuyCourier")
    public boolean getBuyCourier(HttpServletRequest request)
    {
        String orderId=request.getParameter("id");
        return null==buyOrderService.getCourier(Long.parseLong(orderId))?true:false;
    }

    //快递员接单
    @PostMapping("/staff/receivingBuyOrder")
    public boolean receivingBuyOrder(HttpServletRequest request)
    {
        Buyorder order = new Buyorder();
        boolean flag=false;
        if(!getBuyCourier(request))
        {
            String courierId=request.getParameter("courier");
            //获取订单id
            String id=request.getParameter("id");
            order.setCourierid(Long.parseLong(courierId));
            order.setId(Long.parseLong(id));
            flag=buyOrderService.updateBuyOrder(order);

        }
        return flag;
    }

}
