package com.rjxz.xykd.controller;

import com.rjxz.xykd.bean.Admin;
import com.rjxz.xykd.service.IAdminService;
import com.rjxz.xykd.util.IDGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@RestController
public class AdminController {

    @Autowired
    private IAdminService adminService;

    //修改个人中心
    @PostMapping("/admin/updatePersonal")
    public Object editPersonalCenter(HttpServletRequest request){

        HttpSession session = request.getSession(false);
        Admin admin = (Admin) session.getAttribute("account");

        String nickname = request.getParameter("nickname");
        String email = request.getParameter("email");
        short age=new Short(request.getParameter("age"));
        String address = request.getParameter("address");
        String sex = request.getParameter("sex");
        String signature = request.getParameter("signature");
        String phone = request.getParameter("phone");

        admin.setNickname(nickname);
        admin.setAddress(address);
        admin.setAge(age);
        admin.setEmail(email);
        admin.setPhone(phone);
        admin.setSignature(signature);
        admin.setSex(Byte.parseByte(sex));

        if(adminService.update(admin)){
            //将账号更新在session中
            session.setAttribute("admin", admin);
            return session.getAttribute("admin");
        }
        return null;
    }

    //登录
    @GetMapping("/admin/login")
    public Object login(String username, String password){
        return adminService.login(username, password);
    }

    //注册
    @PostMapping("/admin/register")
    public Object register(String username, String password){

        Admin admin = new Admin();
        long id = IDGenerator.getInstance().getId();
        admin.setId(id);
        admin.setEmail(username);
        admin.setPassword(password);
        return adminService.register(admin);
    }
}
