package com.rjxz.xykd.service;

import com.rjxz.xykd.bean.User;

public interface IUserService {

    //登录
    User login(String username, String password);

    //注册
    boolean register(User user);

    //修改个人中心
    boolean update(User user);

    //删除个人信息（管理员权限）
    boolean delete(Long id);

    //获取所有用户信息
    Object getAllUserInfo();
}
