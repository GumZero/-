package com.rjxz.xykd.controller;

import com.rjxz.xykd.bean.Staff;
import com.rjxz.xykd.service.IStaffService;
import com.rjxz.xykd.util.IDGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@RestController
public class StaffController {

    @Autowired
    private IStaffService staffService;

    //修改个人中心信息
    @PostMapping("/staff/updateStaffInfo")
    public Object updateStaffInfo(HttpServletRequest request){
        HttpSession session = request.getSession(false);
        Staff staff = (Staff) session.getAttribute("account");

        String nickname = request.getParameter("nickname");
        String idNumber= request.getParameter("idNumber");
        String email = request.getParameter("email");
        short age=new Short(request.getParameter("age"));
        //前端提交的时间格式yyyy-MM-dd
        Timestamp jointime=Timestamp.valueOf(request.getParameter("jointime"));

        String address = request.getParameter("address");
        String sex = request.getParameter("sex");
        String signature = request.getParameter("signature");
        String phone = request.getParameter("phone");

        staff.setNickname(nickname);
        staff.setIdnumber(idNumber);
        staff.setAddress(address);
        staff.setJointime(jointime);
        staff.setAge(age);
        staff.setEmail(email);
        staff.setPhone(phone);
        staff.setSignature(signature);
        staff.setSex(Byte.parseByte(sex));

        if(staffService.update(staff)){
            //将账号更新在session中
            session.setAttribute("staff", staff);
            return session.getAttribute("staff");
        }
        return null;
    }

    //查看所有快递员
    @GetMapping("/admin/getAllStaff")
    public Object getAllStaffInfo() {
        return staffService.getAllStaffInfo();
    }

    //删除快递员信息
    @GetMapping("/admin/deleteStaffInfo")
    public boolean deleteStaffInfo(HttpServletRequest request){

        Long staffId=Long.parseLong(request.getParameter("staffId"));
        return staffService.delete(staffId);
    }


    //登录
    @GetMapping("/staff/login")
    public Object login(String username, String password){
        return staffService.login(username, password);
    }

    //注册
    @PostMapping("/staff/register")
    public Object register(String username, String password){

        Staff staff = new Staff();
        long id = IDGenerator.getInstance().getId();
        staff.setId(id);
        staff.setEmail(username);
        staff.setPassword(password);
        return staffService.register(staff);

    }

}
