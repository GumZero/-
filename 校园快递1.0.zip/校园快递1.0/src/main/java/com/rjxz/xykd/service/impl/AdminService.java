package com.rjxz.xykd.service.impl;

import com.rjxz.xykd.bean.Admin;
import com.rjxz.xykd.dao.AdminMapper;
import com.rjxz.xykd.service.IAdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminService implements IAdminService {

    @Autowired
    private AdminMapper adminMapper;

    @Override
    public Admin login(String username, String password) {
        return adminMapper.selectByEmailAndPwd(username, password);
    }

    @Override
    public boolean register(Admin admin) {
        int result = adminMapper.insert(admin);
        return result > 0 ? true : false;
    }

    @Override
    public boolean update(Admin admin) {
        int result = adminMapper.updateByPrimaryKey(admin);
        return result > 0 ? true : false;
    }
}
