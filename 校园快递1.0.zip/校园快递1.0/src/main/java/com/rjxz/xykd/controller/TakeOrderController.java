package com.rjxz.xykd.controller;

import com.rjxz.xykd.bean.Takeorder;
import com.rjxz.xykd.bean.User;
import com.rjxz.xykd.service.ITakeOrderService;
import com.rjxz.xykd.util.IDGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.sql.Timestamp;

@RestController
public class TakeOrderController {

    @Autowired
    private ITakeOrderService takeOrderService;

    @PostMapping("/user/submitOrderTake")
    public Object submitOrderTake(HttpServletRequest request){

        //物品类型
        String itemType = request.getParameter("itemType");
        //备注
        String notes = request.getParameter("notes");
        //收货地址
        String receiverAddr = request.getParameter("receiverAddr");
        //收货备注地址
        String receiverNoteAddr = request.getParameter("receiverNoteAddr");
        //收货电话
        String phone = request.getParameter("phone");
        //购买地址
        String takeAddr = request.getParameter("takeAddr");
        //购买备注地址
        String takeNoteAddr = request.getParameter("takeNoteAddr");

        //获取当前系统时间
        Timestamp time = new Timestamp(System.currentTimeMillis());

        //绑定用户
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("account");
        long userId = user.getId();

        Takeorder order = new Takeorder();
        long id = IDGenerator.getInstance().getId();
        order.setId(id);
        order.setNotes(notes);
        order.setPhone(phone);
        order.setReceiveraddr(receiverAddr);
        order.setReceivernoteaddr(receiverNoteAddr);
        order.setUserid(userId);
        order.setTakeaddr(takeAddr);
        order.setTakenoteaddr(takeNoteAddr);
        order.setCourierid(null);
        order.setItemtype(itemType);
        order.setTime(time);

        return takeOrderService.submitOrderTake(order);
    }

    @GetMapping("/user/getOrderTakeList")
    public Object getOrderTakeList(HttpServletRequest request){

        long userId =  Long.parseLong(request.getParameter("userId"));
        return takeOrderService.getOrderTakeList(userId);
    }

    //获取全部代买订单
    @GetMapping("/admin/getAllTakeOrder")
    public Object getAllBuyOrder()
    {
        return takeOrderService.getAllTakeOrder();
    }

    //修改代买订单
    @PostMapping("/admin/updateTakeOrder")
    public boolean updateTakeOrder(HttpServletRequest request)
    {
        boolean flag=false;
        Takeorder order = new Takeorder();

        order.setId(Long.parseLong(request.getParameter("id")));
        order.setItemtype(request.getParameter("itemtype"));
        order.setNotes(request.getParameter("notes"));
        order.setReceiveraddr(request.getParameter("receiverAddr"));
        order.setReceivernoteaddr(request.getParameter("receiverNoteAddr"));
        order.setPhone(request.getParameter("phone"));
        //待定
        order.setTakeaddr(request.getParameter("takeAddr"));
        order.setTakenoteaddr(request.getParameter("takeNoteAddr"));

        order.setUserid(Long.parseLong(request.getParameter("userId")));
        order.setCourierid(Long.parseLong(request.getParameter("courier")));

        flag=takeOrderService.updateTakeOrder(order);
        return flag;
    }

    //删除订单
    @PostMapping("/admin/deleteTakeOrder")
    public boolean deleteTakeOrder(HttpServletRequest request)
    {
        boolean flag=false;
        Takeorder order = new Takeorder();
        //获取订单id
        String orderId=request.getParameter("id");
        flag= takeOrderService.deleteTakeOrder(Long.parseLong(orderId));
        return flag;
    }

    //获取未接订单
    @PostMapping("/staff/getUndoneTakeOrder")
    public Object getUndoneTakeOrder(){
        return takeOrderService.getUndoneOrder();
    }

    //查询订单是否已被抢
    @GetMapping("/staff/getTakeCourier")
    public Object getTakeCourier(HttpServletRequest request)
    {
        boolean flag=false;
        Takeorder order = new Takeorder();
        //获取订单id
        String orderId=request.getParameter("id");
        if(null==takeOrderService.getCourier(Long.parseLong(orderId)))
        {
            flag=true;
        }
        return flag;
    }

    //接单
    @PostMapping("/staff/receivingTakeOrder")
    public Object receivingTakeOrder(HttpServletRequest request)
    {
        boolean flag=false;
        Takeorder order = new Takeorder();
        if((boolean)getTakeCourier(request))
        {
            return flag;
        }
        else
        {
            String courierId=request.getParameter("courierId");
            String id=request.getParameter("id");
            order.setCourierid(Long.parseLong(courierId));
            order.setId(Long.parseLong(id));
            flag=takeOrderService.updateTakeOrder(order);
            return flag;
        }
    }



}
