package com.rjxz.xykd.controller;

import com.rjxz.xykd.bean.Sendorder;
import com.rjxz.xykd.bean.User;
import com.rjxz.xykd.service.impl.SendOrderService;
import com.rjxz.xykd.util.IDGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.sql.Timestamp;

@RestController
public class SendOrderController {

    @Autowired
    private SendOrderService sendOrderService;


    @PostMapping("/user/submitOrderSend")
    public Object submitOrderSend(HttpServletRequest request){

        //物品类型
        String itemType = request.getParameter("itemType");
        //备注
        String notes = request.getParameter("notes");
        //收货地址
        String receiverAddr = request.getParameter("receiverAddr");
        //收货备注地址
        String receiverNoteAddr = request.getParameter("receiverNoteAddr");
        //收货电话
        String phone = request.getParameter("phone");
        //购买地址
        String sendAddr = request.getParameter("sendAddr");
        //购买备注地址
        String sendNoteAddr = request.getParameter("sendNoteAddr");

        //获取当前系统时间
        Timestamp time = new Timestamp(System.currentTimeMillis());

        //绑定用户
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("account");
        long userId = user.getId();

        Sendorder order = new Sendorder();
        long id = IDGenerator.getInstance().getId();
        order.setId(id);
        order.setNotes(notes);
        order.setPhone(phone);
        order.setReceiveraddr(receiverAddr);
        order.setReceivernoteaddr(receiverNoteAddr);
        order.setUserid(userId);
        order.setCourierid(null);
        order.setItemtype(itemType);
        order.setSendaddr(sendAddr);
        order.setSendnoteaddr(sendNoteAddr);
        order.setTime(time);
        return sendOrderService.submitOrderSend(order);
    }

    @GetMapping("/user/getOrderSendList")
    public Object getOrderSendList(HttpServletRequest request){

        long userId =  Long.parseLong(request.getParameter("userId"));
        return sendOrderService.getOrderSendList(userId);
    }

    //获取全部代送订单
    @PostMapping("/admin/getAllSendOrder")
    public Object getAllSendOrder()
    {
        return sendOrderService.getAllSendOrder();
    }

    //修改代送订单
    @PostMapping("/admin/updateSendOrder")
    public boolean updateSendOrder(HttpServletRequest request)
    {
        boolean flag=false;
        Sendorder order = new Sendorder();
        order.setId(Long.parseLong(request.getParameter("id")));
        order.setItemtype(request.getParameter("itemtype"));
        order.setNotes(request.getParameter("notes"));
        order.setReceiveraddr(request.getParameter("receiverAddr"));
        order.setReceivernoteaddr(request.getParameter("receiverNoteAddr"));
        order.setPhone(request.getParameter("phone"));
        order.setSendaddr(request.getParameter("buyAddr"));
        order.setSendnoteaddr(request.getParameter("buyNoteAddr"));
        order.setUserid(Long.parseLong(request.getParameter("userId")));
        order.setCourierid(Long.parseLong(request.getParameter("courier")));

        flag=sendOrderService.updateSendOrder(order);
        return flag;
    }

    //删除订单
    @PostMapping("/admin/deleteSendOrder")
    public boolean deleteSendOrder(HttpServletRequest request)
    {
        boolean flag=false;
        //获取订单id
        String orderId=request.getParameter("id");
        flag= sendOrderService.deleteSendOrder(Long.parseLong(orderId));
        return flag;
    }

    //获取未接订单
    @PostMapping("/staff/getUndoneSendOrder")
    public Object getUndoneSendOrder(){
        return sendOrderService.getUndoneOrder();
    }

    //查询订单是否被接
    @PostMapping("/staff/getSendCourier")
    public boolean getSendCourier(HttpServletRequest request)
    {
        boolean flag=false;
        Sendorder order = new Sendorder();
        //获取订单id
        String orderId=request.getParameter("id");
        if(null==sendOrderService.getCourier(Long.parseLong(orderId)))
        {
            flag=true;
        }
        return flag;
    }

    //接收订单
    @PostMapping("/staff/receivingSendOrder")
    public boolean receivingSendOrder(HttpServletRequest request)
    {
        boolean flag=false;
        Sendorder order = new Sendorder();
        if(getSendCourier(request))
        {
            return flag;
        }
        else
        {
            String courierId=request.getParameter("courier");
            order.setCourierid(Long.parseLong(courierId));
            flag=sendOrderService.updateSendOrder(order);
            return flag;
        }
    }

}
