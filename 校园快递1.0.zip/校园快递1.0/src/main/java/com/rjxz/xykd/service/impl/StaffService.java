package com.rjxz.xykd.service.impl;

import com.rjxz.xykd.bean.Staff;
import com.rjxz.xykd.dao.StaffMapper;
import com.rjxz.xykd.service.IStaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StaffService implements IStaffService {

    @Autowired
    private StaffMapper staffMapper;

    @Override
    public Staff login(String username, String password) {
        return staffMapper.selectByEmailAndPwd(username, password);
    }

    @Override
    public boolean register(Staff staff) {
        int result = staffMapper.insert(staff);
        return result > 0 ? true : false;
    }

    @Override
    public boolean update(Staff staff) {
        int result = staffMapper.updateByPrimaryKey(staff);
        return result > 0 ? true : false;
    }

    @Override
    public boolean delete(Long id) {
        int result=staffMapper.deleteByPrimaryKey(id);
        return result > 0 ? true : false;
    }

    @Override
    public Object getAllStaffInfo() {
        List<Staff> allUserInfo=staffMapper.selectAll();
        return allUserInfo;
    }

}
