package com.rjxz.xykd.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PageController {

    /*
    返回用户页面
     */
    @GetMapping("/getRLPage")
    public String getSignUpHtml(){
        return "rl";
    }

    @GetMapping("/index")
    public String getIndexHtml(){
        return "index";
    }

}
