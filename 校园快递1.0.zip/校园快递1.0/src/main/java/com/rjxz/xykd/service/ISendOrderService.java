package com.rjxz.xykd.service;

import com.rjxz.xykd.bean.Sendorder;

import java.util.List;

public interface ISendOrderService {

    //提交代送订单
    boolean submitOrderSend(Sendorder ordersend);

    Object getAllSendOrder();

    //查询用户代买订单
    List<Sendorder> getOrderSendList(long userId);

    //修改代送订单
    boolean updateSendOrder(Sendorder ordersend);

    //删除代送订单
    boolean deleteSendOrder(Long id);

    //查看未接订单
    Object getUndoneOrder();

    //查看订单接单人
    String getCourier(Long id);

}
