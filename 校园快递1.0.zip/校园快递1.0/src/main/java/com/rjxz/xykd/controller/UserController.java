package com.rjxz.xykd.controller;

import com.rjxz.xykd.bean.User;
import com.rjxz.xykd.service.IUserService;
import com.rjxz.xykd.util.IDGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@RestController
public class UserController {

    @Autowired
    private IUserService userService;

    //修改密码并返回新的个人账号
    @PostMapping("/user/updatePassword")
    public Object updatePassword(HttpServletRequest request){

        String password = request.getParameter("password");

        HttpSession session = request.getSession(false);

        User user = (User)session.getAttribute("account");
        user.setPassword(password);

        if(userService.update(user)){
            //将账号更新在session中
            session.setAttribute("account", user);
            return session.getAttribute("account");
        }
        return null;

    }

    //注销
    @GetMapping("/user/logout")
    public Object logout(HttpServletRequest request){

        HttpSession session = request.getSession(false);
        session.removeAttribute("account");
        return true;

    }

    //修改个人中心并返回新的个人账号
    @PostMapping("/user/updateProfile")
    public Object editPersonalCenter(HttpServletRequest request){

        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("account");

        String nickname = request.getParameter("nickname");
        String email = request.getParameter("email");
        String address = request.getParameter("address");
        String sex = request.getParameter("sex");
        String signature = request.getParameter("signature");
        String phone = request.getParameter("phone");
        String city = request.getParameter("city");

        user.setNickname(nickname);
        user.setAddress(address);
        user.setEmail(email);
        user.setPhone(phone);
        user.setSignature(signature);
        user.setSex(Byte.parseByte(sex));

        if(userService.update(user)){
            //将账号更新在session中
            session.setAttribute("account", user);
            return session.getAttribute("account");
        }
        return null;
    }

    //登录并返回个人账号
    @GetMapping("/user/login")
    public Object login(HttpServletRequest request, HttpServletResponse response){

        String email = request.getParameter("email");
        String password = request.getParameter("password");
        boolean checked = Boolean.parseBoolean(request.getParameter("checked"));
        HttpSession session = request.getSession();
        User user = userService.login(email, password);

        System.out.println(user);

        //将用户的账号信息放在cookie中并发送到浏览器
        if(checked != false){

            ObjectMapper objectMapper = new ObjectMapper();
            String accountJson = null;
            try {
                accountJson = objectMapper.writeValueAsString(user);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
            Cookie cookie = new Cookie("account", accountJson);
            cookie.setMaxAge(1000*60*60*24*7);
            cookie.setPath("/login_user");
            response.addCookie(cookie);
        }

        session.setAttribute("account", user);
        return user;
    }

    //注册并返回个人账号的json
    @PostMapping("/user/register")
    public Object register(HttpServletRequest request){

        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        HttpSession session = request.getSession();

        User user = new User();
        long id = IDGenerator.getInstance().getId();
        user.setId(id);
        user.setNickname(username);
        user.setEmail(email);
        user.setPassword(password);

        if(userService.register(user)){
            //将账号更新在session中
            session.setAttribute("account", user);
            return user;
        }
        return null;
    }

    //删除用户信息--管理员用
    @PostMapping("/admin/deleteUserInfo")
    public boolean deleteUserInfo(HttpServletRequest request) {

        Long userId=Long.parseLong(request.getParameter("userId"));
        return userService.delete(userId);
    }

    //查看所有用户
    @GetMapping("/admin/getAllUser")
    public Object getAllUserInfo() {
        return userService.getAllUserInfo();
    }

}
