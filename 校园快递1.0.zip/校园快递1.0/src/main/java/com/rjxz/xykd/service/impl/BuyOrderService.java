package com.rjxz.xykd.service.impl;

import com.rjxz.xykd.bean.Buyorder;
import com.rjxz.xykd.dao.BuyorderMapper;
import com.rjxz.xykd.service.IBuyOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BuyOrderService implements IBuyOrderService {

    @Autowired
    private BuyorderMapper buyOrderMapper;

    @Override
    public boolean submitOrderBuy(Buyorder orderbuy) {

        int result = buyOrderMapper.insert(orderbuy);
        return result > 0 ? true : false;
    }

    @Override
    public Object getAllBuyOrder() {
        return buyOrderMapper.selectAll();
    }

    public List<Buyorder> getOrderBuyList(long userId){

        List<Buyorder> orderbuyList = buyOrderMapper.selectAllByUserId(userId);
        return orderbuyList;
    }

    @Override
    public Object getUndoneOrder() {
        List<Buyorder> undoneOrders= buyOrderMapper.selectUndoneOrder();
        return undoneOrders;
    }

    @Override
    public String getCourier(Long id) {
        return buyOrderMapper.getCourierById(id);
    }

    @Override
    public boolean deleteBuyOrder(Long id) {
        boolean flag=false;
        if(buyOrderMapper.deleteByPrimaryKey(id)>0)
            flag=true;
        return flag;
    }

    @Override
    public boolean updateBuyOrder(Buyorder buyOrder) {
        boolean flag=false;
        if(buyOrderMapper.updateByPrimaryKey(buyOrder)>0)
            flag=true;
        return flag;
    }
}
