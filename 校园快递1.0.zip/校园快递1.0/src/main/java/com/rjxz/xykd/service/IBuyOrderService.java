package com.rjxz.xykd.service;


import com.rjxz.xykd.bean.Buyorder;

import java.util.List;

public interface IBuyOrderService {

    //提交代买订单
    boolean submitOrderBuy(Buyorder orderbuy);

    Object getAllBuyOrder();

    //查看个人所有代买订单
    List<Buyorder> getOrderBuyList(long userId);

    //修改代买订单
    boolean updateBuyOrder(Buyorder buyOrder);
    //删除代买订单
    boolean deleteBuyOrder(Long id);
    //查看未接订单
    Object getUndoneOrder();
    //查看订单接单人
    String getCourier(Long id);


}
