package com.rjxz.xykd.service;

import com.rjxz.xykd.bean.Staff;

public interface IStaffService {

    //登录
    Staff login(String username, String password);

    //注册
    boolean register(Staff staff);

    //修改个人中心
    boolean update(Staff staff);


    //删除个人信息（管理员权限）
    boolean delete(Long id);

    //获取所有快递员信息
    Object getAllStaffInfo();
}
