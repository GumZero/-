package com.rjxz.xykd.service.impl;

import com.rjxz.xykd.bean.Sendorder;
import com.rjxz.xykd.dao.SendorderMapper;
import com.rjxz.xykd.service.ISendOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SendOrderService implements ISendOrderService {

    @Autowired
    private SendorderMapper sendOrderMapper;

    @Override
    public boolean submitOrderSend(Sendorder ordersend) {

        int result = sendOrderMapper.insert(ordersend);
        return result > 0 ? true : false;
    }

    @Override
    public Object getAllSendOrder() {
        return sendOrderMapper.selectAll();
    }

    @Override
    public List<Sendorder> getOrderSendList(long userId) {

        List<Sendorder> ordersendList = sendOrderMapper.selectAllByUserId(userId);
        return ordersendList;
    }

    @Override
    public Object getUndoneOrder() {
        return sendOrderMapper.selectUndoneOrder();
    }

    @Override
    public String getCourier(Long id) {
        return sendOrderMapper.getCourierById(id);
    }

    @Override
    public boolean updateSendOrder(Sendorder sendorder) {
        boolean flag=false;
        if(sendOrderMapper.updateByPrimaryKey(sendorder)>0)
            flag=true;
        return flag;
    }

    @Override
    public boolean deleteSendOrder(Long id) {
        boolean flag=false;
        if(sendOrderMapper.deleteByPrimaryKey(id)>0)
            flag=true;
        return flag;
    }

}
