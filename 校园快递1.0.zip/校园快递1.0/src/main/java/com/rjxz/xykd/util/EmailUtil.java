package com.rjxz.xykd.util;


import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

public class EmailUtil {

    public static String sendEmail(String address, String personal) throws Exception{

        Properties properties = new Properties();
        //使用什么协议发送邮件
        properties.setProperty("mail.transport.protocol","smtp");
        //邮件服务器地址
        properties.setProperty("mail.smtp.host","smtp.sina.com");
        //安全验证
        properties.setProperty("mail.smtp.auth","true");
        //创建邮件会话
        Session session = Session.getDefaultInstance(properties);
        //创建邮件对象
        MimeMessage mimeMessage = new MimeMessage(session);
        //设置发件人
        mimeMessage.setFrom(new InternetAddress("hsxywwj@sina.com","Campus Courier官方","utf-8"));
        //设置收件人
        mimeMessage.setRecipient(MimeMessage.RecipientType.TO,new InternetAddress(address, personal,"UTF-8"));
        //设置主题
        mimeMessage.setSubject("Campus Courier","utf-8");
        //设置校园骑士验证码
        String emailCode = (int) (Math.random()*100000+100000) + "";
        //设置内容
        mimeMessage.setContent("校园快递验证码:"+emailCode,"text/html;charset=utf-8");
        mimeMessage.saveChanges();
        //发送
        Transport transport = session.getTransport();
        //授权给信使帮我发邮件
        transport.connect("hsxywwj@sina.com","a12345678@WWJ");
        transport.sendMessage(mimeMessage,mimeMessage.getAllRecipients());
        transport.close();
        return emailCode;
    }

}
