package com.rjxz.xykd.service.impl;

import com.rjxz.xykd.bean.Takeorder;
import com.rjxz.xykd.dao.TakeorderMapper;
import com.rjxz.xykd.service.ITakeOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TakeOrderService implements ITakeOrderService {

    @Autowired
    private TakeorderMapper takeOrderMapper;

    @Override
    public boolean submitOrderTake(Takeorder ordertake) {

        int result = takeOrderMapper.insert(ordertake);
        return result > 0 ? true : false;
    }

    @Override
    public Object getAllTakeOrder() {
        return takeOrderMapper.selectAll();
    }

    @Override
    public List<Takeorder> getOrderTakeList(long userId) {

        List<Takeorder> ordertakeList = takeOrderMapper.selectAllByUserId(userId);
        return ordertakeList;
    }

    @Override
    public boolean updateTakeOrder(Takeorder ordertake) {
        boolean flag=false;
        if(takeOrderMapper.updateByPrimaryKey(ordertake)>0)
            flag=true;
        return flag;
    }

    @Override
    public boolean deleteTakeOrder(Long id) {
        boolean flag=false;
        if(takeOrderMapper.deleteByPrimaryKey(id)>0)
            flag=true;
        return flag;
    }

    @Override
    public Object getUndoneOrder() {
        List<Takeorder> undoneOrders=takeOrderMapper.selectUndoneOrder();
        return  undoneOrders;
    }

    @Override
    public String getCourier(Long id) {
        return takeOrderMapper.getCourierById(id);
    }
}
