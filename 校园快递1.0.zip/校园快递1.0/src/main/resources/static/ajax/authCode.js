$(function(){

    //比较输入的验证码和图片上的验证码是否一致
    $("#codeStr").on("blur",function () {
        var value = $(this).val();
        $.ajax({
            type:"GET",
            url: "/getCodeStr",
            dataType:"text",
            success:function(msg){
                if(value != msg){
                    alert("验证码错误");
                }
            }
        });
    });

    //生成验证码图片的ajax
    $("#nextImg").on("click",function () {
        var img = document.getElementById("codeImg");
        var xhr = createRequest();
        xhr.open("POST","/getCodeImg",true);
        xhr.onload = function () {
            if(this.status == 200){
                var blob = this.response;
                img.onload = function (ev) { window.revokeObjectURL(this.src); };
                img.src = window.URL.createObjectURL(blob);
            }
        };
        xhr.responseType = "blob";
        $("#codeStr").val("");
        xhr.send(null);
    });

    //页面加载完成后触发生成图片验证码的事件
    $("#nextImg").click();
});
