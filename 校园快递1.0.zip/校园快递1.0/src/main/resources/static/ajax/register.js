//注册的ajax请求
$(function () {

    $("#submitBtn2").on("click",function () {



        var phone = $("#phone").val();
        var email = $("#email").val();
        var password = $("#register-password").val();
        var repwd = $("#re-password").val();
        var user = $('input[name="sign-up-user"]:checked').val();

        if(phone.length == 0|| password.length==0||email.length==0){
            return;
        }

        if(password != repwd){
            alert("原密码与确认密码不一致!");
            return;
        }

        $.post("/register.do","phone="+phone+"&email="+email+"&password="+password+"&user="+user,function (data) {
            alert(data+"已经注册成功!");
        });
    });

});