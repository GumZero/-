$(function(){

    //提交登录表单请求的ajax
    $("#submitBtn1").on("click",function(){


        var username = $("#username").val();
        var password = $("#login-password").val();
        var user = $('input[name="login-user"]:checked').val();

        //如果用户名和密码不完整,这不提交表单
        if(username.length == 0|| password.length==0){
            return;
        }

        //提交表单
        $.post("/login.do","username="+username+"&password="+password+"&user="+user,function (msg) {
            if(msg == "true"){
                alert("登录成功!");
            }else{
                alert("登录失败!");
            }
        });

    });

});