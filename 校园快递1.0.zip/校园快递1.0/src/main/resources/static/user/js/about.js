window.onload = function()
{
   $(".goodtype").on("mouseover",function(e){
   		var id = e.target.getAttribute("id");  
		if(id == "sGood")
		{   	
			$("#flow1").html("<strong>1.</strong>联系收货人<br/>确认发货地点和物品规格");    	
			$("#flow2").html("<strong>2.</strong>前往发货地点取货<br/>对物品拍照留证");    	
			$("#flow3").html("<strong>3.</strong>取货后联系收货人<br/>确认收货时间和地点");
			$("#flow4").html("<strong>4.</strong>前往发货地点<br/>按时到达,完成上门服务");
		}
		else if(id == "tGood")
		{  
		    $("#flow1").html("<strong>1.</strong>联系收货人<br/>确认发货地点和物品规格");
			$("#flow2").html("<strong>2.</strong>前往发货地点取货<br/>对物品拍照留证");
			$("#flow3").html("<strong>3.</strong>取货后联系收货人<br/>确认收货时间和地点");   	
		    $("#flow4").html("<strong>4.</strong>前往发货地点<br/>按时到达,完成送货");
		}
		else if(id == "bGood")
		{       
		    $("#flow1").html("<strong>1.</strong>联系发货人<br/>确认购买地点和购买要求");       	
		    $("#flow2").html("<strong>2.</strong>前往指定地点购买<br/>并索要购物小票");       
		    $("#flow3").html("<strong>3.</strong>购物成功后联系收货人<br/>确认收货地点和收货时间");
		    $("#flow4").html("<strong>4.</strong>前往收货地点<br/>按时到达并完成");
		}
		switchPic(id);	
   });

}

function switchPic(id)
{
    if(id=="bGood")
    { 
       $("#flow1Pic").attr("src","images/buy_help1.png");
       $("#flow2Pic").attr("src","images/buy_help2.png");
       $("#flow3Pic").attr("src","images/buy_help3.png");
    }
    else if(id == "sGood")
    {
       $("#flow1Pic").attr("src","images/send_help1.png");
       $("#flow2Pic").attr("src","images/send_help2.png");
       $("#flow3Pic").attr("src","images/send_help3.png");

    }
    else if(id == "tGood")
    {
       $("#flow1Pic").attr("src","images/take-help1.png");
       $("#flow2Pic").attr("src","images/take_help2.png");
       $("#flow3Pic").attr("src","images/take_help3.png");
    }
}

