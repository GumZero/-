$(function(){
    //提交登录表单请求的ajax
    $("#submitBtn1").on("click",function(){

        var username = $("#username").val();
        var password = $("#login-password").val();

        //如果用户名和密码不完整,这不提交表单
        if(username.length == 0|| password.length==0){
            return;
        }

        //提交表单
        $.post("/login.do","username="+username+"&password="+password+"&user=USER",function (msg) {
            if(msg == "true"){
                window.location.href="index.html";
            }else{
                alert("登录失败!");
            }
        });

    });

    $("#submitBtn2").on("click",function () {

        var phone = $("#phone").val();
        var email = $("#email").val();
        var password = $("#register-password").val();

        $.post("/register.do","phone="+phone+"&email="+email+"&password="+password+"&user=USER",function (data) {
            alert("你好"+data);
        });
    });

});



