//异步检查用户名是否存在
$(function () {

    $("#username").on("blur",function(){
        var username = $("#username").val();

        $.get("/checkName.do","username=" + username+"&user=USER",function (data) {

            if(data == "true"){
                alert("抱歉,用户名已存在!");
            }else{
                alert("可以使用");
            }

        });
    });
});