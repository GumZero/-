//验证手机号和邮箱和密码一致性
$(function () {

    //验证邮箱
    $("#email").on("blur",function () {
        var value = $(this).val();
        var reg = new RegExp("^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$");
        if(value.length!=0){
            //邮箱格式不对
            if(!reg.test(value)){
                $("#emailHelp").html("格式错误").removeClass().addClass("text-danger");
            }else {
                $("#emailHelp").html("OK").removeClass().addClass("text-success");
            }
        }else {
            //邮箱不能为空
            $("#emailHelp").html("不能为空").removeClass().addClass("text-danger");
        }
    });

    //验证手机号
    $("#phone").on("blur",function () {
        var value = $(this).val();
        var reg = new RegExp("^[1][3,4,5,7,8][0-9]{9}$");
        if(value.length!=0){
            //手机号格式不对
            if(!reg.test(value)){
                $("#phoneHelp").html("格式错误").removeClass().addClass("text-danger");
            }else {
                $("#phoneHelp").html("OK").removeClass().addClass("text-success");
            }
        }else {
            //手机号不能为空
            $("#phoneHelp").html("不能为空").removeClass().addClass("text-danger");
        }
    });

});
