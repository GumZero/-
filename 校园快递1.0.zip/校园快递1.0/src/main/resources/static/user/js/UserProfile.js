$("#nickname").on("blur",function () {
    var val = $(this).val();
    $.post("/updatePwd.do","nickname="+val+"&type=nickname&user=USER",function (data) {
        if(data){
            alert(data);
            //修改成功
        }
    });
});

$("#sex").on("blur",function () {
    var val = $(this).val();
    $.post("/updatePwd.do","sex="+val+"&type=sex&user=USER",function (data) {
        if(data){
            alert(data);
            //修改成功
        }
    });
});

$("#phone").on("blur",function () {
    var val = $(this).val();
    $.post("/updatePwd.do","phone="+val+"&type=phone&user=USER",function (data) {
        if(data){
            alert(data);
            //修改成功
        }
    });
});

$("#city").on("blur",function () {
    var val = $(this).val();
    $.post("/updatePwd.do","city="+val+"&type=city&user=USER",function (data) {
        if(data){
            alert(data);
            //修改成功
        }
    });
});

$("#email").on("blur",function () {
    var val = $(this).val();
    $.post("/updatePwd.do","email="+val+"&type=email&user=USER",function (data) {
        if(data){
            alert(data);
            //修改成功
        }
    });
});

$("#address").on("blur",function () {
    var val = $(this).val();
    $.post("/updatePwd.do","address="+val+"&type=address&user=USER",function (data) {
        if(data){
            alert(data);
            //修改成功
        }
    });
});

$("#signature").on("blur",function () {
    var val = $(this).val();
    $.post("/updatePwd.do","signature="+val+"&type=signature&user=USER",function (data) {
        if(data){
            alert(data);
            //修改成功
        }
    });
});
